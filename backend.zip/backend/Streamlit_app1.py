import streamlit as st
import config
import logging
import json
from textwrap import dedent
import time
import psutil
import subprocess
from threading import Thread
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer, BitsAndBytesConfig

from NL2SQL import NL2SQL
from intent_classifier import IntentClassifier
from rag_setup import RagSetup
import date_parser

# --- Logging Setup ---
# (Assuming config.setup_logging() is defined elsewhere and sets up standard logging)
config.setup_logging()
logger = logging.getLogger(__name__)
logger.info("Logging has been successfully set up.")

# --- Initialization and Caching of Models ---
@st.cache_resource
def initialize_services():
    """
    Initializes and caches the LLM, Tokenizer, and other services.
    This function runs only once when the Streamlit app starts.
    """
    logger.info("Starting service initialization...")

    # --- Device Setup ---
    if torch.cuda.is_available():
        device = torch.device("cuda")
        logger.info(f"Using GPU: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        logger.info("Using CPU")

    # --- Quantization Configuration ---
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16
    )

    # --- Load Tokenizer and Models ---
    try:
        logger.info(f"Loading tokenizer for model: {config.MISTRAL_MODEL_PATH}")
        tokenizer = AutoTokenizer.from_pretrained(config.MISTRAL_MODEL_PATH)
        tokenizer.pad_token = tokenizer.eos_token

        logger.info(f"Loading model: {config.MISTRAL_MODEL_PATH}. This may take a while...")

        # For NL2SQL
        base_model_nl2sql = AutoModelForCausalLM.from_pretrained(
            config.MISTRAL_MODEL_PATH,
            quantization_config=bnb_config,
            device_map="auto"
        )

        # For Summarization and general use
        base_model_summarizer = AutoModelForCausalLM.from_pretrained(
            config.MISTRAL_MODEL_PATH,
            quantization_config=bnb_config,
            device_map="auto"
        )
        logger.info("LLM Models Initialized Successfully.")

        classifier_obj = IntentClassifier(base_model_summarizer, tokenizer)
        logger.info("Intent Classifier Initialized Successfully.")

        nl2sql_obj = NL2SQL(base_model_nl2sql, tokenizer)
        logger.info("NL2SQL Model Initialized Successfully.")

        rag_obj = RagSetup()
        logger.info("RAG Setup Initialized Successfully.")

        logger.info("All services initialized successfully.")
        
        return base_model_summarizer, tokenizer, device, classifier_obj, rag_obj, nl2sql_obj

    except Exception as e:
        logger.critical("Failed to initialize one or more services.", exc_info=True)
        st.error(f"Critical Error: Failed to initialize services. Please check the logs. Error: {e}")
        st.stop()

# --- Load all services ---
base_model_summarizer, tokenizer, device, classifier_obj, rag_obj, nl2sql_obj = initialize_services()

# --- Inference Logic ---
def stream_inference_generator(messages):
    """
    Generator function to stream response tokens.
    """
    start_time = time.time()
    token_count = 0
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)

    try:
        inputs = tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_tensors="pt"
        ).to(device)

        generation_kwargs = dict(
            input_ids=inputs,
            streamer=streamer,
            max_new_tokens=1024,
            do_sample=True,
            temperature=1,
            top_p=0.9,
            top_k=50
        )

        thread = Thread(target=base_model_summarizer.generate, kwargs=generation_kwargs)
        thread.start()

        for token in streamer:
            token_count += 1
            yield token

        thread.join()
        total_time = time.time() - start_time
        if total_time > 0:
            logger.info(f"Total Tokens: {token_count}, Total Time: {total_time:.2f}s, Avg Tokens/Sec: {token_count/total_time:.3f}")

        cpu_percent = psutil.cpu_percent(interval=0.1)
        logger.info(f"CPU Usage: {cpu_percent}%")

        try:
            gpu_info = subprocess.check_output(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total", "--format=csv,nounits,noheader"]).decode("utf-8").strip()
            logger.info(f"GPU Stats: {gpu_info}")
        except Exception as gpu_err:
            logger.warning(f"GPU monitoring failed: {gpu_err}")

    except Exception as e:
        logger.error("Error during Transformers streaming", exc_info=True)
        yield "Error generating response. Please try again later."

# --- Main Streamlit App Logic ---
st.title("📄 Chat with Your Data")
st.write("This interface allows you to interact with your database and documents.")

# Initialize chat history in session state
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display previous messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if "sql_query" in message:
            st.code(message["sql_query"], language="sql")
        if "sources" in message:
            for source in message["sources"]:
                st.info(source, icon="ℹ️")

# Handle user input
if prompt := st.chat_input("Ask me anything about your data..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Normalize dates in the user's message
    normalized_prompt = date_parser.normalize_dates_in_text(prompt)

    # Prepare for response generation
    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        full_response = ""
        sql_query_to_send = None
        unique_sources = []

        # 1. Classify Intent
        intent = classifier_obj.classify_query(normalized_prompt)
        
        # This will hold the conversation history for the model
        messages_for_llm = []

        # 2. Handle different intents
        if intent == config.CLASS_LABELS[0]: # NL2SQL
            sql_text = nl2sql_obj.generate_query_using_llm(normalized_prompt)
            if sql_text:
                clean_sql = nl2sql_obj.extract_sql(sql_text)
                validation_status, _ = nl2sql_obj.validate_sql_syntax(clean_sql)
                
                if validation_status:
                    try:
                        df_result = nl2sql_obj.execute_query(clean_sql)
                        num_rows = len(df_result)
                        logger.info(f"Total number of rows in the result = {num_rows}")

                        if num_rows == 0:
                            full_response = "No records found matching your query. Reframe your query or provide more details about you question."
                            response_placeholder.markdown(full_response)
                        elif num_rows > 5:
                            full_response = f"Your query returned {num_rows} records, which may be too large to display. Would you like to apply additional filters?"
                            response_placeholder.markdown(full_response)
                        else:
                            sql_query_to_send = clean_sql
                            preview_rows = df_result.head(5)
                            system_prompt = "You are a helpful assistant skilled at summarizing database results. Provide a clear, concise natural language summary of the data."
                            messages_for_llm.append({"role": "system", "content": system_prompt})
                            messages_for_llm.append({
                                "role": "user",
                                "content": f"User prompt: {normalized_prompt}\nGenerated SQL: {clean_sql}\nTop rows:\n{preview_rows}\n\nPlease summarize the result."
                            })
                            # Stream the response
                            stream = stream_inference_generator(messages_for_llm)
                            full_response = st.write_stream(stream)
                            response_placeholder.markdown(full_response)
                            
                    except Exception as e:
                        error_msg = f"There was an error executing your query: {str(e)}\nWould you like to rephrase your question?"
                        logger.error(error_msg)
                        full_response = error_msg
                        response_placeholder.markdown(full_response)
                else:
                    intent = config.CLASS_LABELS[1] # Fallback to RAG if SQL is invalid
            else:
                intent = config.CLASS_LABELS[1] # Fallback to RAG if no SQL is generated

        # --- Intent Handling for RAG and General Chat ---
        # This block will execute if the intent is not NL2SQL or if NL2SQL fails
        if intent != config.CLASS_LABELS[0]:
            context = ""
            if intent == config.CLASS_LABELS[1]: # FAULT_INFO
                try:
                    context, _ = rag_obj.retrieve_from_collection(config.FAULT_INFO_COLLECTION, normalized_prompt)
                    system_prompt = dedent("""
                        You are an expert fault-diagnosis assistant for Accelerator Control systems.
                        You must answer the user's question using ONLY the information provided in the context below.
                        Do not use any outside knowledge. If the answer is not in the context, say so.
                    """)
                    logger.info("Using RAG-based prompt for FAULT_INFO.")
                except Exception as e:
                    logger.error(f"Error retrieving from FAULT_INFO collection: {e}")
                    full_response = f"Error fetching fault info: {e}"
                    response_placeholder.markdown(full_response)
            
            elif intent == config.CLASS_LABELS[2]: # DOMAIN_INFO
                try:
                    context, unique_sources = rag_obj.retrieve_from_collection(config.DOMAININFO_COLLECTION, normalized_prompt)
                    system_prompt = "You are a helpful assistant. Use the provided context to answer the question."
                    logger.info("Using RAG-based prompt for DOMAININFO.")
                except Exception as e:
                    logger.error(f"Error retrieving from DOMAININFO collection: {e}")
                    # Fallback to general model if retrieval fails
                    context = ""

            # Prepare messages for LLM
            if context:
                messages_for_llm.append({"role": "system", "content": system_prompt})
                user_content_with_context = f"Context:\n{context}\n\nQuestion:\n{normalized_prompt}"
                messages_for_llm.append({"role": "user", "content": user_content_with_context})
            else: # General chat
                messages_for_llm.append({"role": "user", "content": normalized_prompt})
            
            # Stream the response
            if not full_response: # Ensure we don't overwrite an error message
                stream = stream_inference_generator(messages_for_llm)
                full_response = st.write_stream(stream)
                response_placeholder.markdown(full_response)
        
        # Append final assistant message to session state
        assistant_message = {"role": "assistant", "content": full_response}
        if sql_query_to_send:
            assistant_message["sql_query"] = sql_query_to_send
            st.code(sql_query_to_send, language="sql")
        if unique_sources:
            assistant_message["sources"] = [f"Source [{i+1}]: {src}" for i, src in enumerate(unique_sources)]
            for source in assistant_message["sources"]:
                st.info(source, icon="ℹ️")

        st.session_state.messages.append(assistant_message)