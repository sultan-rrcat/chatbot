import os
import json
from flask import Flask, request, Response, render_template
from textwrap import dedent
import logging
import time
import psutil
import subprocess
from threading import Thread
import date_parser # Assuming this is a custom module
from NL2SQL import NL2SQL # Assuming this is a custom module
from peft import PeftModel


# Hugging Face Transformers and PyTorch imports
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, TextIteratorStreamer, BitsAndBytesConfig

# Assuming you have these modules from your project
import config # Assuming this is a custom module
from intent_classifier import IntentClassifier # Assuming this is a custom module
from rag_setup import RagSetup # Assuming this is a custom module


# --- Flask App Initialization ---
app = Flask(
    __name__,
    static_folder=config.FLASK_APP_STATIC_FOLDER,
    template_folder=config.FLASK_APP_TEMPLATE_FOLDER,
)

# --- Logging Setup ---
config.setup_logging()
logger = logging.getLogger(__name__)
logger.info("📝 Logging has been successfully set up.")

# --- Global Variables for Models and Services ---
model = None
tokenizer = None
device = None
classifier_obj = None
rag_obj = None
nl2sql_obj = None

# --- Inference Logic ---
def stream_inference_generator(messages):
    """
    Generator function to stream response tokens using Hugging Face Transformers.
    It uses a TextIteratorStreamer and runs generation in a separate thread.
    Includes timing and performance logging.
    """
    global model, tokenizer # Ensure we are using the global model and tokenizer
    start_time = time.time()
    token_count = 0

    # Use a streamer for non-blocking, token-by-token generation
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)

    try:
        # Apply the chat template for the specific model
        # This formats the input conversation correctly
        inputs = tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_tensors="pt"
        ).to(device)

        # Keyword arguments for the model's generate method
        generation_kwargs = dict(
            input_ids=inputs,
            streamer=streamer,
            max_new_tokens=512,
            temperature=0.8,
            top_p=0.9,
            do_sample=True,
        )

        # FIX: The target for the thread should be the model's generate method.
        thread = Thread(target=model.generate, kwargs=generation_kwargs)
        thread.start()

        # Yield tokens as they become available
        for token in streamer:
            token_count += 1
            yield f"data: {json.dumps({'chunk': token})}\n\n"

        # Wait for the thread to finish
        thread.join()

        total_time = time.time() - start_time
        if total_time > 0:
            logger.info(f"✅ Total Tokens: {token_count}, Total Time: {total_time:.2f}s, Avg Tokens/Sec: {token_count/total_time:.3f}")

        # Optional: Log CPU usage
        cpu_percent = psutil.cpu_percent(interval=0.1)
        logger.info(f"🖥️ CPU Usage: {cpu_percent}%")

        # Optional: Log GPU usage (NVIDIA only)
        try:
            gpu_info = subprocess.check_output(["nvidia-smi", "--query-gpu=utilization.gpu,memory.used,memory.total", "--format=csv,nounits,noheader"]).decode("utf-8").strip()
            logger.info(f"📈 GPU Stats: {gpu_info}")
        except Exception as gpu_err:
            logger.warning(f"⚠️ GPU monitoring failed: {gpu_err}")

    except Exception as e:
        logger.error("❌ Error during Transformers streaming", exc_info=True)
        error_message = "Error generating response. Please try again later."
        yield f"data: {json.dumps({'error': error_message})}\n\n"


# --- Flask Routes ---
@app.route('/')
def index():
    """Renders the main chat interface."""
    return render_template('index.html')

@app.route('/stream_chat', methods=['POST'])
def stream_chat():
    """Handles the streaming chat request from the frontend."""
    user_message = request.json.get('message')
    if not user_message:
        return Response(f"data: {json.dumps({'error': 'Please enter a message.'})}\n\n", mimetype='text/event-stream', status=400)

    # Normalize any date/time formats in the user's message
    user_message = date_parser.normalize_dates_in_text(user_message)
    
    def generate_response():
        # 1. Classify Intent
        intent = classifier_obj.classify_query(user_message)
        logger.info(f"🔍 Classified Intent: {intent}")

        context = ""
        unique_sources = []
        system_prompt = ""
        
        # This will hold the conversation history for the model
        messages = []
        
        # A flag to check if we should fallback to a different intent
        perform_fallback = False

        # 2. Handle different intents
        if intent == config.CLASS_LABELS[0]: # NL2SQL Intent
            try:
                sql_text = nl2sql_obj.generate_query_using_llm(user_message)
                logger.info(f"Generated SQL Query: {sql_text}")
                clean_sql = nl2sql_obj.extract_sql(sql_text)
                validation_status, _ = nl2sql_obj.validate_sql_syntax(clean_sql)

                if validation_status:
                    result = nl2sql_obj.execute_query(clean_sql)
                    logger.info(f"SQL Execution Result: {result}")
                    
                    # --- NEW NL2SQL Summarization Logic ---
                    # We will now generate a summary using the LLM explicitly for the result
                    summary_messages = [
                        {"role": "system", "content": dedent(f"""
                            You are a helpful assistant skilled at summarizing database results.
                            Based on the user's question and the data retrieved from the database, provide a concise, natural language summary.
                            User prompt: {user_message}
                            Generated SQL: {sql_text}
                            Fetched Result from Database: {result}
                        """).strip()},
                        {"role": "user", "content": "Please summarize the result."}
                    ]
                    
                    # Generate the summary immediately and yield it
                    for token_data in stream_inference_generator(summary_messages):
                        yield token_data
                    # No further processing in this block as the summary is already streamed.
                    # We can then signal completion for this specific path.
                    yield f"data: {json.dumps({'status': 'DONE'})}\n\n"
                    return # Exit the generator after streaming the summary

                else:
                    logger.warning("Invalid SQL Query generated. Falling back to RAG.")
                    perform_fallback = True
            except Exception as e:
                logger.error(f"❌ Error in NL2SQL path: {e}", exc_info=True)
                perform_fallback = True

        if intent == config.CLASS_LABELS[1] and not perform_fallback: # FAULT_INFO Intent
            try:
                context, _ = rag_obj.retrieve_from_collection(config.FAULT_INFO_COLLECTION, user_message)
                system_prompt = dedent("""
                    You are an expert fault-diagnosis assistant for industrial systems.
                    You must answer the user's question using ONLY the information provided in the context below.
                    Do not use any outside knowledge, assumptions, or fabrications. If the answer is not contained in the context, respond with:
                    "The provided context does not contain sufficient information to answer this question."
                    The context may contain technical logs, fault codes, descriptions, and recommended actions. Analyze them carefully before responding.
                """)
                messages.append({"role": "system", "content": system_prompt})
                user_content_with_context = f"Context:\n{context}\n\nQuestion:\n{user_message}"
                messages.append({"role": "user", "content": user_content_with_context})
                logger.info("Using RAG-based prompt for FAULT_INFO.")
            except Exception as e:
                logger.error(f"❌ Error retrieving from FAULT_INFO collection: {e}", exc_info=True)
                messages.append({"role": "user", "content": user_message})
                logger.warning("FAULT_INFO RAG failed. Falling back to general chat.")

        # This block now correctly handles the DOMAININFO intent or the fallback from NL2SQL.
        # This will only be reached if NL2SQL didn't generate a valid summary and return.
        if intent == config.CLASS_LABELS[2] or perform_fallback:
            try:
                context, unique_sources = rag_obj.retrieve_from_collection(config.DOMAININFO_COLLECTION, user_message)
                system_prompt = "You are a helpful assistant. Use the provided context to answer the question."
                messages.append({"role": "system", "content": system_prompt})
                user_content_with_context = f"Context:\n{context}\n\nQuestion:\n{user_message}"
                messages.append({"role": "user", "content": user_content_with_context})
                logger.info("Using RAG-based prompt for DOMAININFO.")
            except Exception as e:
                logger.error(f"❌ Error retrieving from DOMAININFO collection: {e}", exc_info=True)
                messages.append({"role": "user", "content": user_message})
                logger.warning("DOMAININFO RAG failed. Falling back to general chat.")
        
        # General chat, no specific intent or RAG, or if previous RAG/NL2SQL attempts failed to populate messages
        if not messages: # If no specific intent handling populated messages, fall back to general chat
            messages.append({"role": "user", "content": user_message})
            logger.info("Handling as a general chat query.")

        # 4. Stream the LLM response (This will only be called if NL2SQL didn't handle it directly)
        for token_data in stream_inference_generator(messages):
            yield token_data

        # 5. Send sources at the end if they exist
        if unique_sources:
            sources_data = {"sources": [f"Source [{i+1}]: {src}" for i, src in enumerate(unique_sources)]}
            yield f"data: {json.dumps(sources_data)}\n\n"

        # Signal completion
        yield f"data: {json.dumps({'status': 'DONE'})}\n\n"

    return Response(generate_response(), mimetype='text/event-stream')

@app.route('/frontend_log', methods=['POST'])
def frontend_log():
    """Receives and logs messages from the frontend for easier debugging."""
    data = request.get_json()
    logger.info(f"🖥️ [FRONTEND LOG] {data.get('level', 'INFO')}: {data.get('message', 'No message')}")
    return {"status": "logged"}, 200

# --- Application Initialization ---
def initialize_services():
    """Initializes the LLM, Tokenizer, and other services."""
    global model, tokenizer, device, classifier_obj, rag_obj, nl2sql_obj
    logger.info("Starting service initialization...")

    try:
        # --- Device Setup ---
        if torch.cuda.is_available():
            device = torch.device("cuda")
            logger.info(f"Using GPU: {torch.cuda.get_device_name(0)}")
        else:
            device = torch.device("cpu")
            logger.info("Using CPU")

        # --- Quantization Configuration (Optional but Recommended) ---
        # Use 4-bit quantization to reduce memory footprint on GPU
        bnb_config = None
        if torch.cuda.is_available():
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16
            )
            logger.info("✅ 4-bit quantization (bnb) configured for GPU.")

        model_id = config.MISTRAL_MODEL_PATH
        
        logger.info(f"Loading tokenizer for model: {model_id}")
        tokenizer = AutoTokenizer.from_pretrained(model_id)
        tokenizer.pad_token = tokenizer.eos_token

        logger.info(f"Loading base model: {model_id}. This may take a while...")
        base_model = AutoModelForCausalLM.from_pretrained(
            model_id,
            quantization_config=bnb_config, # Will be None if not on GPU
            device_map="auto" # Automatically map model layers to available devices
        )
        logger.info(f"✅ LLM Base Model: {model_id} Initialized Successfully.")

        # --- PEFT Model Loading (Optional) ---
        # If you are using a PEFT-tuned adapter (like LoRA), uncomment the following lines.
        # Make sure to set `config.PEFT_ADAPTER_PATH`.
        # try:
        #    logger.info(f"Loading PEFT adapter from: {config.PEFT_ADAPTER_PATH}")
        #    model = PeftModel.from_pretrained(base_model, config.PEFT_ADAPTER_PATH)
        #    logger.info("✅ PEFT adapter loaded and merged successfully.")
        # except Exception as peft_err:
        #    logger.warning(f"⚠️ Could not load PEFT adapter. Using the base model. Error: {peft_err}")
        #    model = base_model # Fallback to base model
        
        # FIX: The global `model` variable must be assigned the loaded model.
        model = base_model # If not using PEFT, the model is the base model.

    except Exception as e:
        logger.critical("❌ Failed to initialize LLM model.", exc_info=True)
        exit(1)

    try:
        # Pass the final, potentially PEFT-loaded model to the classifier and NL2SQL objects.
        classifier_obj = IntentClassifier(model, tokenizer)
        logger.info("✅ Intent Classifier Initialized Successfully.")
    except Exception as e:
        logger.critical("❌ Failed to initialize intent classifier.", exc_info=True)
        exit(1)

    try:
        nl2sql_obj = NL2SQL(model, tokenizer)
        logger.info("✅ NL2SQL Model Initialized Successfully.")
    except Exception as e:
        logger.critical("❌ Failed to initialize NL2SQL Model.", exc_info=True)
        exit(1)

    try:
        rag_obj = RagSetup()
        logger.info("✅ RAG Setup Initialized Successfully.")
    except Exception as e:
        logger.critical("❌ Failed to initialize RAG setup.", exc_info=True)
        exit(1)

    logger.info("🎉 All services initialized successfully. Application is ready.")


if __name__ == "__main__":
    initialize_services()
    # use_reloader=False is important to prevent re-initialization of models on each code change in debug mode.
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)