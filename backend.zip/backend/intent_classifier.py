import logging
# from llama_cpp import Llama
from transformers import BertTokenizer, BertForSequenceClassification
import torch
import config
import logging
from peft import PeftModel
from transformers import AutoTokenizer, BitsAndBytesConfig, AutoModelForCausalLM


config.setup_logging()
logger = logging.getLogger(__name__)

CLASS_LABELS = config.CLASS_LABELS

class IntentClassifier():
    def __init__(self, base_model, tinyllama_tokenizer):
        
        self.bert_tokenizer = BertTokenizer.from_pretrained(config.BERT_INTENT_CLASSIFIER_MODEL)
        self.bert_classifier_model = BertForSequenceClassification.from_pretrained(config.BERT_INTENT_CLASSIFIER_MODEL)
        self.bert_classifier_model.eval()
        self.llm_classifier_model = PeftModel.from_pretrained(base_model, config.TINYLLAMA_LLM_CLASSIFIER_ADAPTER_PATH, device_map="auto")
        self.tinyllama_tokenizer = tinyllama_tokenizer
    
    def llm_based_classification(self, user_query, max_new_tokens = 32):
        # print(" llm_based_classification ")

        try:
            system_prompt = """You are an intent classification assistant for an accelerator control system chatbot. You receive user queries and classify each into exactly one of the following four categories:

- INTENT1_FAULT_SQL: For queries that require real-time, analytical, or ordered data from the SQL database.
- INTENT2_FAULT_RAG: For queries that need detailed explanations of issues or troubleshooting guidance, using historical logs stored in a vector database.
- INTENT3_DOMAIN_RAG: For questions related to internal information about RRCAT, Indus-1, Indus-2, or Indian accelerator control systems.
- INTENT4_GENERAL_INFO: For all other questions not covered by the above categories.

Respond with only the correct intent label, and nothing else.
"""
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query}
        ]

            # Generate prompt with proper generation trigger:
            try:
                device = next(self.llm_classifier_model.parameters()).device  # Detect model's device
                input_ids = self.tinyllama_tokenizer.apply_chat_template(
                    messages,
                    tokenize=True,
                    add_generation_prompt=True, # Crucial: tells the model it's starting a new assistant turn
                    return_tensors="pt"
                ).to(device)
                # inputs = {k: v.to(device) for k, v in inputs.items()}  # Move tokenized input to model device
            except Exception as e:
                logger.error(f"Tokenization Error: {e}")
                return "ERROR_TOKENIZATION"

            try:
                outputs = self.llm_classifier_model.generate(
                    input_ids=input_ids,
                    max_new_tokens=max_new_tokens,
                    temperature=0.7,
                    top_p=0.9,
                    do_sample=True,
                    eos_token_id=self.tinyllama_tokenizer.eos_token_id,
                    pad_token_id=self.tinyllama_tokenizer.pad_token_id,
                )
            except Exception as e:
                logger.error(f"Model Generation Error: {e}")
                return "ERROR_GENERATION"

            try:
                response = self.tinyllama_tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True).strip()
            except Exception as e:
                logger.error(f"Decoding Error: {e}")
                return "ERROR_DECODING"

            logger.info(f"User Query: {user_query} -> Class: {response}")
            return response

        except Exception as e:
            logger.error(f"Unexpected Error: {e}")
            return "ERROR_UNKNOWN"
        
    def bert_based_classification(self, user_query):
        inputs = self.bert_tokenizer(user_query, return_tensors="pt", truncation=True, padding = True)
        with torch.no_grad():
            outputs = self.bert_classifier_model(**inputs)
        probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
        predicted_class = torch.argmax(probs, dim=1).item()
        return CLASS_LABELS[predicted_class], float(probs.max())

    def rule_based_classification(self, query):
        query = query.lower()
        sql_keywords = ["current", "now", "real-time", "live", "status", "recent", "latest", "order", "average", "per day", "per month", "per hour", "last week", "summarized", "trend", "uptime"]
        fault_keywords = ["fault", "not working", "failure", "issues", "incidents"]
        domain_keywords = ["physics", "rrcat"]

        if any(kw in query for kw in sql_keywords):
            return CLASS_LABELS[0]
        elif any(kw in query for kw in fault_keywords):
            return CLASS_LABELS[2]
        elif any(kw in query for kw in domain_keywords):
            return CLASS_LABELS[3]
        else: 
            return CLASS_LABELS[4]
        
    def classify_query(self, query):
        logging.info(f"Starting classification for query: {query}")

        # LLM-based classification (priority)
        try:
            # print("starting!!")
            llm_label = self.llm_based_classification(query)
            llm_label_clean = llm_label.strip().split()[0]  # handle extra tokens
            logging.info(f"LLM Label: {llm_label_clean}")

            if llm_label_clean in CLASS_LABELS.values():
                logging.info(f"Using LLM-based classification: {llm_label_clean}")
                return llm_label_clean
            else:
                logging.warning(f"LLM returned unexpected label: {llm_label_clean}. Falling back.")
        except Exception as e:
            logging.error(f"LLM classification failed: {e}. Falling back.")

        # BERT-based classification (secondary)
        try:
            bert_label, bert_confidence = self.bert_based_classification(query)
            logging.info(f"BERT Label: {bert_label} | Confidence: {bert_confidence:.2f}")

            if bert_confidence > 0.94:
                logging.info(f"Using BERT-based classification: {bert_label}")
                return bert_label
            else:
                logging.warning(f"BERT confidence low ({bert_confidence:.2f}). Will check rule-based next.")
                return CLASS_LABELS[4]
        except Exception as e:
            logging.error(f"BERT classification failed: {e}. Falling back.")

        


        # Rule-based classification (fallback)
        # try:
        #     rule_label = self.rule_based_classification(query)
        #     logging.info(f"Using rule-based classification: {rule_label}")
        #     return rule_label
        # except Exception as e:
        #     logging.error(f"Rule-based classification failed: {e}. Returning 'Uncertain'.")

        return f"Uncertain"

if __name__ == "__main__":
    '''
    "live_data": ["What is the current beam energy?", "Is the magnet on?", "Live beam status"]
    "historical_data": ["Average uptime last week", "Summarize beam usage", "Trends of beam power"]
    "general": ["Who discovered electrons?", "What is a qubit?", "Define entropy"]
    '''

    prompt_list = ["What is the current beam energy?", "Is the magnet on?", "Live beam status", "Average uptime last week", "Summarize beam usage", "Trends of beam power", "Who discovered electrons?", "What is a qubit?", "Define entropy"]
    prompt = 'show recent faults related to "power supply tripping" issues?'
    bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16
        )
    model_id = config.TINYLLAMA_BASE_MODEL_PATH
    
    logger.info(f"Loading tokenizer for model: {model_id}")
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    tokenizer.pad_token = tokenizer.eos_token
    logger.info(f"Loading model: {model_id}. This may take a while...")
    base_model = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=bnb_config if torch.cuda.is_available() else None, # Only quantize on GPU
        device_map="cuda" # Automatically map model layers to available devices
    )
    base_model.to("cuda")

    # ==============================================
    obj = IntentClassifier(base_model, tokenizer)
    result = f'Prompt: {prompt} \nClassified Result: {obj.classify_query(prompt)}\n'